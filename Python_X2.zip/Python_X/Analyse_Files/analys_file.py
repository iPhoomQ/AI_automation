file_path = 'post_face_auto_01.py'

# Reading the file to analyze the code and understand the issue
with open(file_path, 'r') as file:
    file_content = file.read()

file_content
print(file_content)