from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

# Set up the WebDriver (make sure to specify the path to your WebDriver)
driver = webdriver.Chrome(executable_path='/home/phakphoom/.wdm/drivers/chromedriver/linux64/128.0.6613.119/chromedriver-linux64/chromedriver')

# Step 1: Log in to Facebook
driver.get('https://www.facebook.com/')
time.sleep(2)  # Wait for the page to load

# Enter your email and password
email_input = driver.find_element(By.ID, 'email')
password_input = driver.find_element(By.ID, 'pass')

email_input.send_keys('phakphoom.q@gmail.com')
password_input.send_keys('ManManManNoi99&')

# Click the login button
login_button = driver.find_element(By.NAME, 'login')
login_button.click()
time.sleep(5)  # Wait for the login to complete

# Step 2: Navigate to the status update section
driver.get('https://www.facebook.com/')  # Go to the homepage
time.sleep(5)  # Wait for the page to load

# Step 3: Upload the image
photo_button = driver.find_element(By.XPATH, "//input[@type='file']")
photo_button.send_keys('/home/phakphoom/Downloads/6972728.jpg')  # Path to your image

# Step 4: Post the status
time.sleep(5)  # Wait for the image to upload
post_button = driver.find_element(By.XPATH, "//button[contains(text(), 'Post')]")
post_button.click()

# Close the driver
time.sleep(5)  # Wait for the post to complete
driver.quit()
