import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2  # 2 means block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Facebook login function
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "email"))
        )

        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for login to complete
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        print("Logged in successfully!")
    except Exception as e:
        print("Failed to log in:", str(e))

# Function to create a post
def create_post(driver, message):
    try:
        # Click on "What's on your mind?" element
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()
        
        # Wait for the post input to be available
        post_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div[1]/div/div/div[1]'))
        )
        post_input.click() 
        # Ensure the input field is focused
        post_input.send_keys(message)  # Set the message content
        print("Post message typed.")

        # Locate and click the "Post" button
        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )
        
        time.sleep(1)  # Optional delay
        driver.execute_script("arguments[0].click();", post_button)  # Use JavaScript to click

        print("Post submitted!")
    except Exception as e:
        print("Failed to create a post:", str(e))

def main():
    """
    Main function to log in and create a post.
    """
    username = 'phakphoom.q@gmail.com'  # Replace with your actual username
    password = 'ManManManNoi99&'  # Replace with your actual password
    message = ['Hello Sunday', 'Hello Friend','Hello Everybody']

    # Set up the WebDriver using Service and ChromeDriverManager
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        # Log in to Facebook
        login_facebook(driver, username, password)

        # Post the message
        create_post(driver, message)

    finally:
        # Wait a few seconds before closing the browser
        time.sleep(5)
        driver.quit()

if __name__ == "__main__":
    main()
