import tkinter as tk
from tkinter import messagebox
import random
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Function to send OTP email
def send_email(receiver_email, otp_code):
    # Define sender email and password here
    sender_email = "phakphoom.q@gmail.com"  # Replace with your email address
    sender_password = "nfsh gsko zdxy uopw"  # Replace with your email account password or app-specific password

    # Set up the SMTP server and login
    smtp_server = "smtp.gmail.com"  # Replace with your SMTP server (e.g., smtp.gmail.com for Gmail)
    smtp_port = 587  # Usually 587 for TLS, 465 for SSL

    try:
        # Create the email message
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver_email
        msg['Subject'] = "Your OTP Code"

        # Email body
        body = f"Your OTP code is: {otp_code}"
        msg.attach(MIMEText(body, 'plain'))

        # Connect to the server and send the email
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()  # Use TLS
        server.login(sender_email, sender_password)
        text = msg.as_string()
        server.sendmail(sender_email, receiver_email, text)

        # Disconnect from the server
        server.quit()

        print("Email sent successfully!")

    except Exception as e:
        print(f"Failed to send email: {e}")
        raise

# Tkinter application for login and OTP verification
class LoginApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Login Page")
        self.root.geometry("300x250")

        self.email_label = tk.Label(root, text="Email")
        self.email_label.pack(pady=10)
        self.email_entry = tk.Entry(root)
        self.email_entry.pack(pady=5)

        self.signup_button = tk.Button(root, text="Sign Up", command=self.send_otp)
        self.signup_button.pack(pady=20)

    def send_otp(self):
        self.user_email = self.email_entry.get()
        if self.user_email:
            self.otp = self.generate_otp()
            # Send OTP to the user's email
            try:
                send_email(self.user_email, self.otp)
                messagebox.showinfo("Success", f"OTP sent to {self.user_email}")
                self.verify_otp()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to send OTP: {e}")
        else:
            messagebox.showwarning("Input Error", "Please enter your email address.")

    def generate_otp(self):
        return str(random.randint(100000, 999999))

    def verify_otp(self):
        otp_window = tk.Toplevel(self.root)
        otp_window.title("Verify OTP")
        otp_window.geometry("300x150")

        otp_label = tk.Label(otp_window, text="Enter OTP")
        otp_label.pack(pady=10)
        self.otp_entry = tk.Entry(otp_window)
        self.otp_entry.pack(pady=5)

        verify_button = tk.Button(otp_window, text="Verify", command=self.check_otp)
        verify_button.pack(pady=20)

    def check_otp(self):
        entered_otp = self.otp_entry.get()
        if entered_otp == self.otp:
            messagebox.showinfo("Success", "OTP Verified!")
        else:
            messagebox.showerror("Error", "Invalid OTP!")

# Create Tkinter window
root = tk.Tk()
app = LoginApp(root)
root.mainloop()
