import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def send_email_with_html_and_attachment(smtp_server, smtp_port, sender_email, sender_password, receiver_email, subject, html_content, attachment_path):
    # Create a multipart message
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject

    # Attach the HTML body
    msg.attach(MIMEText(html_content, 'html'))

    # Open the file to be sent
    with open(attachment_path, 'rb') as attachment:
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(attachment.read())

    # Encode the file in base64
    encoders.encode_base64(part)

    # Add header
    part.add_header('Content-Disposition', f'attachment; filename= {attachment_path.split("/")[-1]}')

    # Attach the file to the message
    msg.attach(part)

    # Create SMTP session for sending the email
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()  # Enable security
        server.login(sender_email, sender_password)  # Login to the email account
        text = msg.as_string()  # Convert the message to a string
        server.sendmail(sender_email, receiver_email, text)  # Send the email

# Your provided information
smtp_server = 'smtp.gmail.com'
smtp_port = 587
sender_email = 'phakphoom.q@gmail.com'
sender_password = 'nfsh gsko zdxy uopw'
receiver_email = 'asia_proud@yahoo.com'
subject = 'Subject of the Email'
html_content = """
<html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Analytics Style Visualization with Starry Sky</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            overflow: hidden;
            background-color: #000;
        }
        .container-fluid {
            position: relative;
            height: 100%;
        }
        #backgroundCanvas, #canvas {
            position: absolute;
            top: 0;
            left: 0;
            z-index: 1;
        }
        #canvas {
            z-index: 2;
        }
        .content {
            position: relative;
            z-index: 3;
            color: white;
            text-align: center;
            margin-top: 10%;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <canvas id="backgroundCanvas"></canvas>
    <canvas id="canvas"></canvas>
    <div class="content">
        <h1>Data Analytics Visualization</h1>
        <p>This visualization represents data points and their connections in a dynamic style.</p>
        <button class="btn btn-primary">Explore More</button>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    const numDots = 500;
    const numStars = 200;
    const dots = [];
    const stars = [];
    const backgroundCanvas = document.getElementById('backgroundCanvas');
    const backgroundCtx = backgroundCanvas.getContext('2d');
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');

    canvas.width = backgroundCanvas.width = window.innerWidth;
    canvas.height = backgroundCanvas.height = window.innerHeight;

    // Star object with properties for position and size
    function createStar() {
        return {
            x: Math.random() * backgroundCanvas.width,
            y: Math.random() * backgroundCanvas.height,
            size: Math.random() < 0.5 ? 1 : 2, // 50% small stars, 50% big stars
            opacity: Math.random() * 0.8 + 0.2 // Random opacity for star flicker effect
        };
    }

    // Dot object with properties for position and size
    function createDot() {
        const rand = Math.random();
        let size = 1;  // Default size

        if (rand < 0.4) {
            size = 2;  // 50% of dots will be 2px
        } else if (rand < 0.2) {
            size = 3;  // 10% of dots will be 3px
        }

        return {
            x: Math.random() * canvas.width,
            y: Math.random() * canvas.height,
            size: size, // Size determined by random chance
            dx: Math.random() * 2 - 1,
            dy: Math.random() * 2 - 1
        };
    }

    for (let i = 0; i < numStars; i++) {
        stars.push(createStar());
    }

    for (let i = 0; i < numDots; i++) {
        dots.push(createDot());
    }

    function drawStars() {
        backgroundCtx.clearRect(0, 0, backgroundCanvas.width, backgroundCanvas.height);
        stars.forEach(star => {
            backgroundCtx.beginPath();
            backgroundCtx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
            backgroundCtx.fillStyle = `rgba(255, 255, 255, ${star.opacity})`;
            backgroundCtx.fill();
        });
    }

    function drawDots() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        dots.forEach((dot, i) => {
            // Update dot position
            dot.x += dot.dx;
            dot.y += dot.dy;

            // Keep dots within the canvas
            if (dot.x < 0 || dot.x > canvas.width) dot.dx *= -1;
            if (dot.y < 0 || dot.y > canvas.height) dot.dy *= -1;

            // Draw dot
            ctx.beginPath();
            ctx.arc(dot.x, dot.y, dot.size, 0, Math.PI * 2);
            ctx.fillStyle = '#fff';
            ctx.fill();

            // Draw lines connecting dots
            for (let j = i + 1; j < dots.length; j++) {
                const otherDot = dots[j];
                const dist = Math.hypot(dot.x - otherDot.x, dot.y - otherDot.y);
                if (dist < 100) {
                    ctx.beginPath();
                    ctx.moveTo(dot.x, dot.y);
                    ctx.lineTo(otherDot.x, otherDot.y);
                    ctx.strokeStyle = `rgba(255, 255, 255, ${1 - dist / 120})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            }
        });

        requestAnimationFrame(drawDots);
    }

    drawStars();
    drawDots();

    // Handle window resize
    window.addEventListener('resize', () => {
        canvas.width = backgroundCanvas.width = window.innerWidth;
        canvas.height = backgroundCanvas.height = window.innerHeight;
        drawStars();
    });

</script>

</body>
</html>
"""
attachment_path = 'email_management.py'

send_email_with_html_and_attachment(smtp_server, smtp_port, sender_email, sender_password, receiver_email, subject, html_content, attachment_path)
