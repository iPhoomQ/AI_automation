import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Email credentials
smtp_user = 'phakphoom.q@gmail.com'
smtp_password = "nfsh gsko zdxy uopw"

# Email configuration
smtp_server = 'smtp.gmail.com'
smtp_port = 587

# Sample contacts
contacts = [
    {'name': 'John Doe', 'email': 'silicon_so2@yahoo.com', 'address': '123 Main St, City, Country'},
    {'name': 'Jane Smith', 'email': 'asia_proud@yahoo.com', 'address': '456 Elm St, City, Country'},
]

def send_email(to_email, subject, body):
    try:
        # Set up the server
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_user, smtp_password)

        # Compose the email
        msg = MIMEMultipart()
        msg['From'] = smtp_user
        msg['To'] = to_email
        msg['Subject'] = subject

        # Attach the body with the message instance (HTML format)
        msg.attach(MIMEText(body, 'html'))

        # Send the message
        server.send_message(msg)
        server.quit()
        print(f"Email sent to {to_email}")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication failed: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Loop through the contacts and send an email to each
for contact in contacts:
    name = contact['name']
    address = contact['address']
    to_email = contact['email']

    # Customize your email body (HTML with <marquee> and font style)
    email_body = f"""
    <html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Email</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .email-container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .header {
            background-color: #0073e6;
            color: #ffffff;
            padding: 10px 0;
            text-align: center;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 20px;
        }
        .content h2 {
            color: #0073e6;
            font-size: 22px;
            margin-bottom: 15px;
        }
        .content p {
            color: #333333;
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .button {
            text-align: center;
            margin: 20px 0;
        }
        .button a {
            background-color: #0073e6;
            color: #ffffff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }
        .button a:hover {
            background-color: #005bb5;
        }
        .footer {
            font-size: 14px;
            text-align: center;
            color: #888888;
            margin-top: 30px;
        }
        .footer a {
            color: #0073e6;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <!-- Header Section -->
        <div class="header">
            <h1>Your Company Name</h1>
        </div>

        <!-- Content Section -->
        <div class="content">
            <h2>Dear [Recipient's Name],</h2>
            <p>
                We are pleased to inform you about an important update in our services. Your experience with us is
                of the utmost importance, and we strive to ensure continuous improvement.
            </p>
            <p>
                Our new features are designed to help your business thrive. We hope you take full advantage of these changes.
            </p>

            <!-- Call to Action Button -->
            <div class="button">
                <a href="#">Explore Now</a>
            </div>
        </div>

        <!-- Footer Section -->
        <div class="footer">
            <p>If you have any questions, feel free to <a href="mailto:contact@yourcompany.com">contact us</a>.</p>
            <p>&copy; 2024 Your Company Name. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

    """

    # Send the email
    send_email(to_email, 'Address Update Notification', email_body)

print("Emails have been processed.")
