
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Email credentials
smtp_user = 'phakphoom.q@gmail.com'
smtp_password = "nfsh gsko zdxy uopw"

# Email configuration
smtp_server = 'smtp.gmail.com'
smtp_port = 587

# Sample contacts
contacts = [
    {'name': 'John Doe', 'email': 'silicon_so2@yahoo.com', 'address': '123 Main St, City, Country'},
    {'name': 'Jane Smith', 'email': 'asia_proud@yahoo.com', 'address': '456 Elm St, City, Country'},
]

def send_email(to_email, subject, body):
    try:
        # Set up the server
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_user, smtp_password)

        # Compose the email
        msg = MIMEMultipart()
        msg['From'] = smtp_user
        msg['To'] = to_email
        msg['Subject'] = subject

        # Attach the body with the message instance (HTML format)
        msg.attach(MIMEText(body, 'html'))

        # Send the message
        server.send_message(msg)
        server.quit()
        print(f"Email sent to {to_email}")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication failed: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Loop through the contacts and send an email to each
for contact in contacts:
    name = contact['name']
    address = contact['address']
    to_email = contact['email']

    # Customize your email body (HTML with <marquee> and font style)
    email_body = '''
<html>
<head>
    <style>
        @keyframes scroll {{
            0% {{ transform: translateX(100%); }}
            100% {{ transform: translateX(-100%); }}
        }}

        @keyframes zoom {{
            0%, 100% {{ transform: scale(1); }}
            50% {{ transform: scale(1.5); }}
        }}

        .marquee {{
            font-family: Verdana, sans-serif;
            color: red;
            font-size: 16px;
            white-space: nowrap;
            display: block;
            overflow: hidden;
            position: relative;
            width: 100%;
            animation: scroll 10s linear infinite;
        }}

        .marquee span {{
            display: inline-block;
            animation: zoom 3s ease-in-out infinite;
        }}
    </style>
</head>
<body>
    <h2 style="font-family: Arial, sans-serif; color: blue;">Dear {name},</h2>
    <p style="font-family: 'Times New Roman', serif; font-size: 16px; color: black;">
        This is a message to inform you about the update regarding your address:
    </p>

    <p style="font-family: 'Courier New', monospace; font-size: 14px; color: green;">
        New Address: <strong>{address}</strong>
    </p>

    <div class="marquee">
        <span>This is your animated message scrolling from right to left with zoom effect!</span>
    </div>

    <p style="font-family: Arial, sans-serif; color: black;">
        Please verify the changes.
    </p>
    <p style="font-family: Arial, sans-serif; color: gray;">
        Best regards,<br>Your Company Name
    </p>
</body>
</html>
'''

    # Send the email
    send_email(to_email, 'Address Update Notification', email_body)

print("Emails have been processed.")
