import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Email credentials
smtp_user = 'phakphoom.q@gmail.com'
smtp_password = "nfsh gsko zdxy uopw"

# Email configuration
smtp_server = 'smtp.gmail.com'
smtp_port = 587

# Sample contacts
contacts = [
    {'name': 'John Doe', 'email': 'silicon_so2@yahoo.com', 'address': '123 Main St, City, Country'},
    {'name': 'Jane Smith', 'email': 'asia_proud@yahoo.com', 'address': '456 Elm St, City, Country'},
]

def send_email(to_email, subject, body):
    try:
        # Set up the server
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_user, smtp_password)

        # Compose the email
        msg = MIMEMultipart()
        msg['From'] = smtp_user
        msg['To'] = to_email
        msg['Subject'] = subject

        # Attach the body with the message instance (HTML format)
        msg.attach(MIMEText(body, 'html'))

        # Send the message
        server.send_message(msg)
        server.quit()
        print(f"Email sent to {to_email}")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication failed: {e}")
    except Exception as e:
        print(f"An error occurred: {e}")

# Loop through the contacts and send an email to each
for contact in contacts:
    name = contact['name']
    address = contact['address']
    to_email = contact['email']

    # Customize your email body (HTML with <marquee> and font style)
    email_body = f"""
    <html>
    <body>
        <h2 style="font-family: Arial, sans-serif; color: blue;">Dear {name},</h2>
        <p style="font-family: 'Times New Roman', serif; font-size: 16px; color: black;">
            This is a message to inform you about the update regarding your address:
        </p>

        <p style="font-family: 'Courier New', monospace; font-size: 14px; color: green;">
            New Address: <strong>{address}</strong>
        </p>

        <marquee style="font-family: Verdana, sans-serif; color: red; font-size: 16px;">
            This is your animated message scrolling from right to left!
        </marquee>
        <div style="font-family: Arial, sans-serif; background-color: yellow; font-size: 28px; color: blue; padding: 30px;">
            Your message here
        </div>


<p style="font-family: Arial, sans-serif; background-color: yellow; padding: 5px; color: black;">
    Important message with a highlighted background!
</p>

<p style="font-family: Arial, sans-serif; color: black; font-size: 20px; text-shadow: 2px 2px 5px grey;">
    Beautiful text with shadow effect!
</p>


        <p style="font-family: Arial, sans-serif; color: black;">
            Please verify the changes.
        </p>
        <p style="font-family: Arial, sans-serif; color: gray;">
            Best regards,<br>Your Company Name
        </p>
    </body>
    </html>
    """

    # Send the email
    send_email(to_email, 'Address Update Notification', email_body)

print("Emails have been processed.")
