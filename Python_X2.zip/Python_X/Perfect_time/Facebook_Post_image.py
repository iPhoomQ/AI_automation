import time
import os
import logging
import glob
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2  # Block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Facebook login function
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "email"))
        )
        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for login to complete
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        logging.info("Logged in successfully!")
    except TimeoutException:
        logging.error("Login operation timed out.")
    except Exception as e:
        logging.error(f"Failed to log in: {str(e)}")

# Function to create a post with image
def create_post(driver, message, image_path):
    try:
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()

        post_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div[1]/div/div/div[1]'))
        )
        post_input.click()
        post_input.send_keys(message)
        logging.info("Post message typed.")

        # Upload an image
        image_upload_button = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//input[@type='file' and @accept='image/*,image/heif,image/heic']"))
        )
        image_upload_button.send_keys(image_path)  # Provide the image file path to upload
        logging.info(f"Image {image_path} uploaded.")

        # Wait for the image to be uploaded completely
        time.sleep(3)  # You might want to improve this by checking an element when the image is ready.

        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )
        driver.execute_script("arguments[0].click();", post_button)
        logging.info("Post submitted!")
    except TimeoutException:
        logging.error("Post creation operation timed out.")
    except Exception as e:
        logging.error(f"Failed to create a post: {str(e)}")

# Function to schedule a post with multiple contents and images
def scheduled_post(driver, email, password, post_contents, images_folder, interval_in_seconds):
    login_facebook(driver, email, password)

    try:
        # List images from folder sorted by creation date (oldest first)
        image_paths = sorted(
            glob.glob(f"{images_folder}/*"),
            key=os.path.getctime
        )

        if len(image_paths) < len(post_contents):
            logging.error("Not enough images to match the number of posts.")
            return

        content_index = 0
        total_contents = len(post_contents)

        while True:
            # Create a post with the current content and image
            create_post(driver, post_contents[content_index], image_paths[content_index])

            # Move to the next content
            content_index = (content_index + 1) % total_contents

            # Wait for the specified time interval before posting again
            logging.info(f"Waiting {interval_in_seconds} seconds before next post...")
            time.sleep(interval_in_seconds)

    except KeyboardInterrupt:
        logging.info("Post scheduling stopped by user.")
    except Exception as e:
        logging.error(f"An error occurred during scheduling: {str(e)}")
    finally:
        driver.quit()

# Set up WebDriver and block notifications
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

# Fetch credentials from the .env file using the dotenv library
email = os.getenv('FACEBOOK_EMAIL')
password = os.getenv('FACEBOOK_PASSWORD')

# Post contents (list of 5 different messages)
post_contents = [
    "This is the first post content!",
    "Here goes the second content.",
    "Posting the third content now.",
    "Fourth message being posted.",
    "Finally, the fifth content!"
]

# Path to the folder containing images
images_folder = "image_upload"

# Time interval between posts
interval_in_seconds = int(input("Enter the post interval in seconds: "))

# Schedule the posts with images
scheduled_post(driver, email, password, post_contents, images_folder, interval_in_seconds)








# add photo at comment   /html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[3]/div[1]/div[2]/div/div[1]/div/span/div/div/div[1]/div/div/div[1]
# add photo button       /html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div/div/div