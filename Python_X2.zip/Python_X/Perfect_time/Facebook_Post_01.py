import time
import os
import logging
import glob
import random
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
from dotenv import load_dotenv
from selenium.webdriver import ActionChains

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2,
    "profile.default_content_setting_values.automatic_downloads": 1,  # Block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Facebook login function
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "email"))
        )
        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for login to complete
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        logging.info("Logged in successfully!")
    except TimeoutException:
        logging.error("Login operation timed out.")
    except Exception as e:
        logging.error(f"Failed to log in: {str(e)}")

# Function to create a post and add a random image
def create_post(driver, message, image_folder):
    try:
        # Select random image from folder
        image_path = random.choice(glob.glob(os.path.join(image_folder, '*')))
        logging.info(f"Selected image: {image_path}")

        # Click on the "What's on your mind?" box to create a post
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()

        # Wait for the text input to appear and type the post message
        post_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div[1]/div/div/div[1]'))
        )
        post_input.click()
        post_input.send_keys(message)
        logging.info("Post message typed.")

        # Add photo by clicking the "Add Photo/Video" button
        add_photo_button_01 = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[3]/div[1]/div[2]/div/div[1]/div/span/div/div/div[1]/div/div/div[1]'))
        )
        add_photo_button_01.click()

        #add_photo_button_02 = WebDriverWait(driver, 30).until(
         #   EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div/div/div'))
        #)
        #add_photo_button_02.click()

        # Upload the photo
        drop_area = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div/div/div'))
        )

        # Create an ActionChain to simulate the drag-and-drop
        action = ActionChains(driver)
        action.click_and_hold(drop_area).move_to_element(drop_area).release().perform()


        photo_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//input[@type='file' and @accept='image/*,image/heif,image/heic']"))
        )
        photo_input.send_keys(image_path)  # Provide the random image file path
        logging.info(f"Image {image_path} uploaded via drag-and-drop.")

        # Wait for the image to be uploaded completely
        WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(@aria-label, 'Your post is ready to share')]"))
        )
        time.sleep(5)   # Small delay to ensure upload completes

        # Click the "Post" button
        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )
        driver.execute_script("arguments[0].click();", post_button)
        logging.info("Post submitted!")
    except TimeoutException:
        logging.error("Post creation operation timed out.")
    except Exception as e:
        logging.error(f"Failed to create a post: {str(e)}")

# Function to schedule a post with a random image
def scheduled_post(driver, email, password, post_content, image_folder, interval_in_seconds):
    login_facebook(driver, email, password)

    try:
        while True:
            create_post(driver, post_content, image_folder)
            logging.info(f"Waiting {interval_in_seconds} seconds before next post...")
            time.sleep(interval_in_seconds)
    except KeyboardInterrupt:
        logging.info("Post scheduling stopped by user.")
    except Exception as e:
        logging.error(f"An error occurred during scheduling: {str(e)}")
    finally:
        driver.quit()

# Set up WebDriver and block notifications
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

# Fetch credentials from environment variables
email = os.getenv('FACEBOOK_EMAIL')
password = os.getenv('FACEBOOK_PASSWORD')

# Content of the post
post_content = input("Enter your message here: ")

# Path to the folder containing images
image_folder = os.path.join(os.getcwd(), 'images')  # Assumes 'images' folder in the same directory

# Time interval between posts
interval_in_seconds = int(input("Enter the post interval in seconds: "))

# Schedule the posts with a random image
scheduled_post(driver, email, password, post_content, image_folder, interval_in_seconds)





#  insert  /html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div/div/div/div[2]