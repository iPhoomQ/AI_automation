import time
import os
import logging
import glob
import random
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)

# Set up Chrome options to block notifications and handle file uploads
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2,  # Block notifications
    "profile.default_content_setting_values.automatic_downloads": 1,
}
chrome_options.add_experimental_option("prefs", prefs)
chrome_options.add_argument("--disable-blink-features=AutomationControlled")

# Facebook login function
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.ID, "email"))
        )
        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for the home page to load by checking for the "Create a post" button
        WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        logging.info("Logged in successfully!")
    except TimeoutException:
        logging.error("Login operation timed out.")
        driver.quit()
    except Exception as e:
        logging.error(f"Failed to log in: {str(e)}")
        driver.quit()

# Function to create a post and add an image automatically
def create_post(driver, message, image_folder):
    try:
        # Select the most recent image from the folder
        image_list = glob.glob(os.path.join(image_folder, '*'))
        if not image_list:
            logging.error("No images found in the specified folder.")
            return
        image_path = max(image_list, key=os.path.getctime)
        logging.info(f"Selected image: {image_path}")

        # Click on the "Create a post" area
        post_area = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        post_area.click()

        # Wait for the post modal to appear
        post_modal = WebDriverWait(driver, 30).until(
            EC.visibility_of_element_located((By.XPATH, "//div[@aria-label='Create post']"))
        )

        # Type the post message
        post_input = post_modal.find_element(By.XPATH, ".//div[@role='textbox']")
        post_input.click()
        post_input.send_keys(message)
        logging.info("Post message typed.")

        # Locate the hidden file input element for uploading images
        file_input = post_modal.find_element(By.XPATH, ".//input[@type='file' and @accept='image/*,image/heif,image/heic']")
        file_input.send_keys(image_path)  # Automatically upload the image
        logging.info(f"Image {image_path} uploaded.")

        # Wait for the image preview to appear
        WebDriverWait(post_modal, 30).until(
            EC.presence_of_element_located((By.XPATH, ".//img[contains(@src, 'data:image')]"))
        )
        logging.info("Image upload confirmed.")

        # Click the "Post" button
        post_button = post_modal.find_element(By.XPATH, ".//div[@aria-label='Post']")
        driver.execute_script("arguments[0].click();", post_button)
        logging.info("Post submitted!")

        # Wait for the post to be submitted and modal to close
        WebDriverWait(driver, 30).until(
            EC.invisibility_of_element(post_modal)
        )
        logging.info("Post modal closed.")

    except TimeoutException:
        logging.error("Post creation operation timed out.")
    except Exception as e:
        logging.error(f"Failed to create a post: {str(e)}")

# Function to schedule a post with an image
def scheduled_post(driver, email, password, post_content, image_folder, interval_in_seconds):
    login_facebook(driver, email, password)

    try:
        while True:
            create_post(driver, post_content, image_folder)
            logging.info(f"Waiting {interval_in_seconds} seconds before next post...")
            time.sleep(interval_in_seconds)
    except KeyboardInterrupt:
        logging.info("Post scheduling stopped by user.")
    except Exception as e:
        logging.error(f"An error occurred during scheduling: {str(e)}")
    finally:
        driver.quit()

if __name__ == "__main__":
    # Set up WebDriver and block notifications
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)

    # Fetch credentials from environment variables
    email = os.getenv('FACEBOOK_EMAIL')
    password = os.getenv('FACEBOOK_PASSWORD')

    if not email or not password:
        logging.error("Facebook credentials not found in environment variables.")
        driver.quit()
        exit(1)

    # Content of the post
    post_content = input("Enter your message here: ")

    # Path to the folder containing images
    image_folder = os.path.join(os.getcwd(), 'images')  # Assumes 'images' folder in the same directory

    # Time interval between posts
    interval_in_seconds = int(input("Enter the post interval in seconds: "))

    # Schedule the posts with an image
    scheduled_post(driver, email, password, post_content, image_folder, interval_in_seconds)
