import re

# Function to extract company details and format them into a dictionary
def extract_company_details(text):
    companies = text.split("--------------------------------------------------")
    company_dicts = {}

    for i, company in enumerate(companies, start=1):
        try:
            # Regular expression to capture company name or replace if it's missing
            company_name_match = re.search(r'([A-Z\s\.,]+CO\.,\sLTD\.)', company)
            company_name = company_name_match.group(1).strip() if company_name_match else None

            company_website = re.search(r'(www\.\S+)', company).group(1).strip()

            # Replace company name if it is "CO., LTD." or not found
            if company_name is None or company_name == "CO., LTD.":
                company_name_base = company_website.replace("www.", "").replace(".com", "").upper()
                company_name = f"{company_name_base} CO., LTD."

            business_description = re.search(r'K\s*(.*)', company).group(1).strip()
            if business_description == "-" or "CO., LTD." in business_description:
                business_description = ""

            contact_person_match = re.search(r'G\s*(.*),\s*(.*)', company)
            contact_person = contact_person_match.group(1).strip() if contact_person_match else "N/A"
            contact_person_position = contact_person_match.group(2).strip() if contact_person_match else "N/A"
            established_year = re.search(r'1\s*(\d{4})', company).group(1).strip()
            employees = re.search(r'P\s*(\d+)\s*employees', company).group(1).strip()
            capital = re.search(r'B\s*(\d+)\s*MB', company).group(1).strip()
            shareholders = re.search(r'L\s*(.*)', company).group(1).strip()
            address = re.search(r'X\s*(.*)', company).group(1).strip()
            phone = re.search(r'T\s*:\s*([^F]+)', company).group(1).strip()
            fax = re.search(r'F\s*:\s*(\S+)', company).group(1).strip()
            email = re.search(r'E\s*:\s*(\S+)', company).group(1).strip()

            company_dict = {
                "company_name": company_name,
                "company_website": company_website,
                "business_description": business_description,
                "contact_person": contact_person,
                "contact_person_position": contact_person_position,
                "established_year": established_year,
                "employees": employees,
                "capital": capital,
                "shareholders": shareholders,
                "address": address,
                "phone": phone,
                "fax": fax,
                "email": email
            }

            # Use the name "Company_Contact" to store all company details
            company_dicts[f"Company_{str(i).zfill(3)}"] = company_dict

        except AttributeError:
            continue

    return company_dicts

# Read the text file
with open('formatted_company_details.txt', 'r') as file:
    content = file.read()

# Extract and format the company details
company_dicts = extract_company_details(content)

# Save the dictionaries to a new Python file
with open('company_data3.py', 'w') as py_file:
    py_file.write("Company_Contact = {\n")
    for var_name, company_dict in company_dicts.items():
        py_file.write(f"    '{var_name}': {company_dict},\n")
    py_file.write("}\n")

print("Company details have been saved as Python dictionaries in 'company_data.py'.")
