import os
import psutil
from tkinter import *
from tkinter import messagebox
from cryptography.fernet import Fernet

# Fixed USB mount point (replace with the actual path if it changes)
USB_MOUNT_POINT = '/media/phakphoom/CCCOMA_X64FRE_EN-GB_DV9/'

# Function to check if the USB is mounted
def get_usb_mount_point():
    if os.path.ismount(USB_MOUNT_POINT):
        print(f"USB drive found at: {USB_MOUNT_POINT}")
        return USB_MOUNT_POINT
    else:
        print("No USB drives found!")
        return None

# Generate encryption key (do this once and store it securely)
def generate_key():
    return Fernet.generate_key()

# Save the key securely (in practice, this should be stored securely)
def save_key_to_file(key, filepath):
    with open(filepath, 'wb') as key_file:
        key_file.write(key)

# Encrypt and save password to USB
def encrypt_and_save_password(password, usb_path, key):
    fernet = Fernet(key)
    encrypted_password = fernet.encrypt(password.encode())
    with open(os.path.join(usb_path, 'password.key'), 'wb') as file:
        file.write(encrypted_password)
    print(f"Password saved to {usb_path}")

# Tkinter window to input password
def prompt_for_password(usb_path, key):
    def save_password():
        password = password_entry.get()
        if password:
            encrypt_and_save_password(password, usb_path, key)
            messagebox.showinfo("Success", "Password saved successfully!")
            root.destroy()  # Close the window after saving

    # Create Tkinter window
    root = Tk()
    root.title("Save Password to USB")
    root.geometry("300x150")

    # Label and entry for password
    label = Label(root, text="Enter Password to Save:", font=("Arial", 12))
    label.pack(pady=10)

    password_entry = Entry(root, show="*", font=("Arial", 12))
    password_entry.pack(pady=5)

    # Save button
    save_button = Button(root, text="Save Password", command=save_password, font=("Arial", 12))
    save_button.pack(pady=10)

    root.mainloop()

# Main function to detect USB, prompt for password, and save it
def main():
    usb_path = get_usb_mount_point()
    if not usb_path:
        return  # No USB found, exit program

    # Ensure USB path is valid
    if os.path.exists(usb_path):
        key = generate_key()  # Generate a new key or load an existing one

        # Prompt the user to input and save a password
        prompt_for_password(usb_path, key)

if __name__ == "__main__":
    main()
