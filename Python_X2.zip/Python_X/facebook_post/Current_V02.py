import time
import os
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Load environment variables
load_dotenv()

# Get credentials from environment variables
email = os.getenv("FACEBOOK_EMAIL", "phakphoom.q@gmail.com")
password = os.getenv("FACEBOOK_PASSWORD", "ManManManNoi99&")

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {"profile.default_content_setting_values.notifications": 2}
chrome_options.add_experimental_option("prefs", prefs)

def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, "email")))

        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)
        driver.find_element(By.NAME, "login").click()

        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        print("Logged in successfully!")
    except Exception as e:
        print("Failed to log in:", str(e))

def create_post(driver, message):
    try:
        # Locate and click on "What's on your mind?" to open the post dialog
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()
        
        # Ensure the contenteditable input box is loaded
        post_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true']"))
        )
        
        # Input the message into the post box
        post_input.click()
        time.sleep(2)  # Short delay to ensure the input box is ready
        post_input.send_keys(message)

        print("Message typed successfully!")

        # Locate and click the "Post" button
        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )
        driver.execute_script("arguments[0].click();", post_button)  # Use JS for reliable clicking

        print("Post submitted!")
    except Exception as e:
        print("Failed to create a post:", str(e))

def scheduled_post(driver, email, password, post_content, interval_in_seconds):
    login_facebook(driver, email, password)
    try:
        while True:
            create_post(driver, post_content)
            print(f"Waiting {interval_in_seconds} seconds before the next post...")
            time.sleep(interval_in_seconds)
    except KeyboardInterrupt:
        print("Post scheduling stopped by user.")
    except Exception as e:
        print("An error occurred during scheduling:", str(e))
    finally:
        driver.quit()

# Set up the WebDriver
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

# Input for post content and interval time
post_content = input("Enter your message here: ")
interval_in_seconds = int(input("Enter the post interval in seconds: "))

# Start the scheduling process
scheduled_post(driver, email, password, post_content, interval_in_seconds)
