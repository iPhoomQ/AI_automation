import requests
from datetime import datetime

# Your access token, app ID, and secret obtained from Facebook Developer settings
access_token = 'EAALzHhyumkcBOyaIM7aTBieNFccOxDHqyWcd4Se7hLhr41jZAzANfYs4uiPd9WOTQvF3gGYb643O3HeKN3G8GeDztJAtr8ytQS5rPDAkZAqNPtBMXlt8QVEWiEcZBHxoHFkcoD5JMkF2WBtYaeZApJSjvD8GlR834IPZC0jkWmhvNQZBcORMD2VNJ5Dvoq2c4oz0geqB6IQHirqCWcrTrmRQkLudA7wC4YyLYTMa3ADvpwdUb5ggFi7rESKXffnAZDZD'
page_id = '61558371130813'

def post_to_facebook(message):
    url = f'https://graph.facebook.com/{page_id}/feed'
    payload = {
        'message': message,
        'access_token': access_token
    }
    response = requests.post(url, data=payload)
    return response.json()

def main():
    message = f"Automated Post: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    response = post_to_facebook(message)
    print(response)

if __name__ == '__main__':
    main()
