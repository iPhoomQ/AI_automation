import time
import random
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Function to post a comment on a Facebook post
def post_comment(driver, comment):
    try:
        # Locate the comment box element by XPath
        comment_box = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Write a comment']"))
        )
        comment_box.click()
        time.sleep(random.uniform(1, 3))  # Random sleep for human-like typing behavior
        
        comment_box.send_keys(comment)
        comment_box.send_keys(Keys.RETURN)
        print("Comment posted!")
    except Exception as e:
        print("Failed to post comment:", str(e))

# Function to search for a topic on Facebook
def search_topic(driver, topic):
    try:
        # Wait until the search box is clickable
        search_box = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//input[@aria-label='Search Facebook']"))
        )
        search_box.click()
        time.sleep(1)

        search_box.send_keys(topic)
        search_box.send_keys(Keys.RETURN)

        # Wait for search results to load
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(text(), 'results')]"))
        )
        print("Search successful!")
    except Exception as e:
        print("Failed to search topic:", str(e))

# Facebook login
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        time.sleep(3)

        # Input email and password
        email_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "email"))
        )
        password_box = driver.find_element(By.ID, "pass")

        email_box.send_keys(email)
        password_box.send_keys(password)

        # Submit login form
        login_button = driver.find_element(By.NAME, "login")
        login_button.click()

        # Wait for login to complete
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        print("Logged in successfully!")
    except Exception as e:
        print("Failed to log in:", str(e))

# Set up the WebDriver using Service and ChromeDriverManager
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

# Facebook login credentials (you can log in manually if you prefer)
email = "phakphoom.q@gmail.com"
password = "ManManNoi77&"

# Log into Facebook
login_facebook(driver, email, password)

# Define the topic you want to search
topic = "AI and Machine Learning"

# Start the search process
search_topic(driver, topic)

# Example comments to post
comments = [
    "Great discussion about AI!",
    "I totally agree with the points made here.",
    "Thanks for sharing this information, very helpful.",
]

# Assume you manually navigate to a post where you want to comment
# Loop through and post 5 comments (you can modify this for more comments)
for i in range(5):
    post_comment(driver, random.choice(comments))  # Post a random comment
    time.sleep(random.uniform(30, 120))  # Random delay between actions

# Close the browser when done
driver.quit()
