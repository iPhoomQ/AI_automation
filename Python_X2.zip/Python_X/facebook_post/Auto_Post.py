import time
import os
import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2  # 2 means block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Facebook login function with retry mechanism
def login_facebook(driver, email, password, retry_count=3):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, "email")))

        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for login to complete
        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']")))
        logging.info("Logged in successfully!")
    except Exception as e:
        logging.error(f"Failed to log in: {e}")
        if retry_count > 0:
            logging.info(f"Retrying login... Attempts left: {retry_count}")
            login_facebook(driver, email, password, retry_count - 1)
        else:
            raise Exception("Failed to login after several attempts")

# Function to create a post
def create_post(driver, message):
    try:
        # Click on "What's on your mind?" element
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()
        
        # Wait for the post input to be available
        post_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true']"))
        )
        post_input.click()  # Ensure the input field is focused
        post_input.send_keys(message)  # Set the message content
        logging.info("Post message typed.")

        # Locate and click the "Post" button
        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )
        time.sleep(1)  # Optional delay
        driver.execute_script("arguments[0].click();", post_button)  # Use JavaScript to click
        logging.info("Post submitted!")
    except Exception as e:
        logging.error(f"Failed to create a post: {e}")
        raise e

# Function to schedule a post at specific intervals
def scheduled_post(driver, email, password, post_content, interval_in_seconds):
    try:
        login_facebook(driver, email, password)

        while True:
            create_post(driver, post_content)
            logging.info(f"Waiting {interval_in_seconds} seconds before next post...")
            time.sleep(interval_in_seconds)
    except KeyboardInterrupt:
        logging.info("Post scheduling stopped by user.")
    except Exception as e:
        logging.error(f"An error occurred during scheduling: {e}")
    finally:
        driver.quit()

if __name__ == "__main__":
    # Set up the WebDriver using Service and ChromeDriverManager, and pass Chrome options to block notifications
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)

    # Facebook login credentials (use environment variables for security)
    email = os.getenv("FB_EMAIL", "phakphoom.q@gmail.com")
    password = os.getenv("FB_PASSWORD", "ManManManNoi99&")

    # Content of the post
    post_content = "This is an automated post created using Selenium!"

    # Time interval in seconds (for example, 86400 seconds for 24 hours)
    interval_in_seconds = 30  # 30 seconds

    # Schedule a post every interval
    scheduled_post(driver, email, password, post_content, interval_in_seconds)
