import os
import time
import openai
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from pytrends.request import TrendReq

# Set up OpenAI API key directly in the script (replace with your actual API key)
openai.api_key = "sk-1g6jm62Mn1AZ2kRuNgkqFCvoU6VoddAzEeuMnXGHC3T3BlbkFJYYJToyu2-1bMRQR8y_j8T397Co0eynaigIcZPtn7oA"
 # Replace with your OpenAI API key
FB_EMAIL = "phakphoom.q@gmail.com"          # Replace with your Facebook email
FB_PASSWORD = "ManManNoi88&"    # Replace with your Facebook password


# Chrome options to block notifications and pop-ups
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2,
    "profile.default_content_setting_values.popups": 2,
}
chrome_options.add_experimental_option("prefs", prefs)

# Function to sanitize text by keeping only BMP characters
def sanitize_text(text):
    # Only keep characters in the BMP range (U+0000 to U+FFFF)
    return ''.join(c for c in text if ord(c) <= 0xFFFF)

# Function to get trending topics using pytrends
def get_trending_topic():
    try:
        pytrends = TrendReq(hl='en-US', tz=360)
        trending_searches_df = pytrends.trending_searches(pn='united_states')
        trending_topic = trending_searches_df.iloc[0, 0]
        print(f"Trending Topic: {trending_topic}")
        return trending_topic
    except Exception as e:
        print(f"Error fetching trending topics: {e}")
        return "Current trends unavailable"

# Function to generate a post using OpenAI
def generate_post(topic):
    prompt = f"Create a Facebook post about the trending topic: {topic}"
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}]
        )
        post_content = response['choices'][0]['message']['content']
        return post_content
    except Exception as e:
        print(f"Error generating post content: {e}")
        return "Trending topic information could not be retrieved at the moment."

# Facebook login function
def login_facebook(driver):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.ID, "email"))).send_keys(FB_EMAIL)
        driver.find_element(By.ID, "pass").send_keys(FB_PASSWORD)
        driver.find_element(By.NAME, "login").click()
        WebDriverWait(driver, 20).until(EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']")))
        print("Logged in successfully!")
    except Exception as e:
        print(f"Login failed: {e}")
        driver.quit()

# Function to create a post on Facebook
def create_post(driver, message):
    try:
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()

        post_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true']"))
        )
        
        # Sanitize message content before sending it to the input box
        sanitized_message = sanitize_text(message)
        
        # Set the sanitized message using JavaScript to avoid issues with non-BMP characters
        driver.execute_script(f"arguments[0].innerHTML = '{sanitized_message}';", post_input)

        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )
        driver.execute_script("arguments[0].click();", post_button)
        print("Post submitted!")
    except Exception as e:
        print(f"Failed to create post: {e}")

# Main function to run the script
def main():
    # Set up the WebDriver
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        # Login to Facebook
        login_facebook(driver)

        # Get trending topic using pytrends
        trending_topic = get_trending_topic()

        # Generate a post using OpenAI
        post_content = generate_post(trending_topic)

        # Create a post on Facebook
        create_post(driver, post_content)

    finally:
        # Close the driver
        driver.quit()

if __name__ == "__main__":
    main()
