import time
import os
import logging
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from webdriver_manager.chrome import ChromeDriverManager
from dotenv import load_dotenv
from selenium.webdriver import ActionChains
from tkinter import *
from tkinter import filedialog
from PIL import ImageTk, Image

# Load environment variables from .env file
load_dotenv()

# Set up logging
logging.basicConfig(level=logging.INFO)

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2,
    "profile.default_content_setting_values.automatic_downloads": 1,  # Block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Facebook login function
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "email"))
        )
        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for login to complete
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        logging.info("Logged in successfully!")
    except TimeoutException:
        logging.error("Login operation timed out.")
    except Exception as e:
        logging.error(f"Failed to log in: {str(e)}")

# Function to create a post and add an image
def create_post(driver, message, image_path):
    try:
        logging.info(f"Selected image: {image_path}")

        # Click on the "What's on your mind?" box to create a post
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()

        # Wait for the text input to appear and type the post message
        post_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[1]/div[1]/div/div/div[1]'))
        )
        post_input.click()
        post_input.send_keys(message)
        logging.info("Post message typed.")

        # Add photo by clicking the "Add Photo/Video" button
        add_photo_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[3]/div[1]/div[2]/div/div[1]/div/span/div/div/div[1]/div/div/div[1]'))
        )
        add_photo_button.click()

        # Upload the photo
        photo_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH,  '/html/body/div[1]/div/div/div[1]/div/div[4]/div/div/div[1]/div/div[2]/div/div/div/form/div/div[1]/div/div/div/div[2]/div[1]/div[2]/div/div[1]/div/div/div/div[1]/div/div/div'))
        )
        photo_input.send_keys(image_path)  # Provide the image file path
        logging.info(f"Image {image_path} uploaded.")

        # Wait for the image to be uploaded completely
        WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//div[contains(@aria-label, 'Your post is ready to share')]"))
        )
        time.sleep(5)   # Small delay to ensure upload completes

        # Click the "Post" button
        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )
        driver.execute_script("arguments[0].click();", post_button)
        logging.info("Post submitted!")
    except TimeoutException:
        logging.error("Post creation operation timed out.")
    except Exception as e:
        logging.error(f"Failed to create a post: {str(e)}")

# Function to schedule a post
def scheduled_post(driver, email, password, post_content, image_path, time_delay):
    login_facebook(driver, email, password)
    create_post(driver, post_content, image_path)
    logging.info(f"Post will be published after a delay of {time_delay} seconds.")
    time.sleep(time_delay)
    driver.quit()

# Tkinter GUI
def open_file_dialog():
    filepath = filedialog.askopenfilename(title="Select an Image", filetypes=[("Image files", "*.jpg *.jpeg *.png")])
    if filepath:
        # Show the selected image
        img = Image.open(filepath)
        img = img.resize((150, 150), Image.LANCZOS)  # Use Image.LANCZOS instead of Image.ANTIALIAS
        img = ImageTk.PhotoImage(img)
        image_label.config(image=img)
        image_label.image = img
        
        # Display the image filename
        image_name_label.config(text=os.path.basename(filepath))

        # Store the image path
        image_path.set(filepath)


def post_to_facebook():
    email = email_entry.get()
    password = password_entry.get()
    message = post_message.get()
    time_delay = int(time_entry.get())
    image = image_path.get()

    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    scheduled_post(driver, email, password, message, image, time_delay)

# GUI Setup
root = Tk()
root.title("Facebook Post Automation")

image_path = StringVar()

# Email
Label(root, text="Facebook Email:").grid(row=0, column=0, padx=10, pady=10)
email_entry = Entry(root, width=30)
email_entry.grid(row=0, column=1, padx=10, pady=10)

# Password
Label(root, text="Facebook Password:").grid(row=1, column=0, padx=10, pady=10)
password_entry = Entry(root, width=30, show='*')
password_entry.grid(row=1, column=1, padx=10, pady=10)

# Message
Label(root, text="Post Message:").grid(row=2, column=0, padx=10, pady=10)
post_message = Entry(root, width=30)
post_message.grid(row=2, column=1, padx=10, pady=10)

# Time Delay
Label(root, text="Time Delay (seconds):").grid(row=3, column=0, padx=10, pady=10)
time_entry = Entry(root, width=30)
time_entry.grid(row=3, column=1, padx=10, pady=10)

# Select Image
Button(root, text="Select Image", command=open_file_dialog).grid(row=4, column=0, padx=10, pady=10)

# Image Preview and Name
image_label = Label(root)
image_label.grid(row=4, column=1, padx=10, pady=10)

# Image Filename Display
image_name_label = Label(root, text="")
image_name_label.grid(row=5, column=1, padx=10, pady=10)

# Post Button
Button(root, text="Post to Facebook", command=post_to_facebook).grid(row=6, columnspan=2, padx=10, pady=10)

root.mainloop()
