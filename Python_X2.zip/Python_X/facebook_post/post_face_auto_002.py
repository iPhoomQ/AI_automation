import time
import logging
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2  # 2 means block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Close any popups or overlays that might appear
def close_popups(driver):
    try:
        # Example XPath for a generic pop-up close button
        popup_close_button = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Not Now') or contains(@aria-label, 'Close')]"))
        )
        popup_close_button.click()
        logger.info("Popup closed.")
    except Exception:
        # No pop-up appeared
        logger.info("No pop-up appeared.")

# Ensure overlays are gone before proceeding
def wait_for_overlays_to_disappear(driver):
    WebDriverWait(driver, 30).until_not(
        EC.presence_of_element_located((By.XPATH, "//div[contains(@class, 'overlay') or contains(@class, 'modal')]"))
    )
    logger.info("Overlays disappeared.")



# Facebook login function
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "email"))
        )

        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for login to complete
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        print("Logged in successfully!")
    except Exception as e:
        print("Failed to log in:", str(e))

# Function to create a post
# Revised create_post function with logging
def create_post(driver, message):
    try:
        # Close any pop-ups that might interfere
        close_popups(driver)

        # Click on "What's on your mind?" element
        post_box = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
        )
        post_box.click()

        # Wait for overlays to disappear
        
        #time.sleep(2)  

        # Wait for the post input to be available and clickable
        post_input = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@contenteditable='true']"))
        )

        # Scroll the input into view and click using JavaScript
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", post_input)
        driver.execute_script("arguments[0].click();", post_input)

        
        #actions = ActionChains(driver)
        #actions.move_to_element(post_input).click().perform()

        # Type the message
        post_input.click()
        post_input.send_keys(message)
        logger.info("Post message typed.")

        # Locate and click the "Post" button
        post_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
        )

        time.sleep(1)  # Optional delay
        driver.execute_script("arguments[0].click();", post_button)  # Use JavaScript to click

        logger.info("Post submitted!")
    except Exception as e:
        # Capture screenshot and page source for debugging
        driver.save_screenshot('error_screenshot.png')
        with open('error_page_source.html', 'w', encoding='utf-8') as f:
            f.write(driver.page_source)
        logger.error("Failed to create a post:", str(e))


# Function to schedule a post at specific intervals
def scheduled_post(driver, email, password, post_content, interval_in_seconds):
    # Login to Facebook
    login_facebook(driver, email, password)

    try:
        while True:
            # Create a post
            create_post(driver, post_content)
            
            # Wait for the specified time interval
            print(f"Waiting {interval_in_seconds} seconds before next post...")
            time.sleep(interval_in_seconds)
    except KeyboardInterrupt:
        print("Post scheduling stopped by user.")
    except Exception as e:
        print("An error occurred during scheduling:", str(e))
    finally:
        driver.quit()

# Set up the WebDriver using Service and ChromeDriverManager, and pass Chrome options to block notifications
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

# Facebook login credentials (consider using environment variables for security)
email = "phakphoom.q@gmail.com"  # Set your environment variable for email
password = "ManManManNoi99&"  # Set your environment variable for password

# Content of the post
post_content = "This is an aHello using Selenium!"

# Time interval in seconds (for example, 86400 seconds for 24 hours)
interval_in_seconds = 30  # 30 seconds

# Schedule a post every interval (e.g., every 30 seconds)
scheduled_post(driver, email, password, post_content, interval_in_seconds)
