import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2  # 2 means block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Set up the WebDriver using Service and ChromeDriverManager, and pass Chrome options to block notifications
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

# Open Facebook
driver.get("https://www.facebook.com/")

# Allow time for the page to load
time.sleep(3)

# Log in to Facebook
email_input = driver.find_element(By.ID, "email")
email_input.send_keys("phakphoom.q@gmail.com")  # Enter your Facebook email

password_input = driver.find_element(By.ID, "pass")
password_input.send_keys("ManManManNoi99&")  # Enter your Facebook password
password_input.send_keys(Keys.RETURN)

# Allow time for the page to load after login
time.sleep(5)

# Navigate to the create post section
create_post_area = driver.find_element(By.XPATH, '//div[@aria-label="Create a post"]')
create_post_area.click()

time.sleep(3)  # Wait for the post dialog to open

# Fill in the post content
post_input_area = driver.find_element(By.XPATH, '//div[@role="textbox"]')
post_input_area.click()
post_input_area.send_keys("This is an automated post created using Selenium!")

# Wait a little before posting
time.sleep(2)

# Find the "Post" button using the provided element structure
post_button = driver.find_element(By.XPATH, '//div[@aria-label="Comment" and @role="button"]')
post_button.click()

# Wait for the post to be submitted
time.sleep(5)

# Close the browser
driver.quit()
