import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2  # 2 means block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Facebook login function
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "email"))
        )

        # Input email and password
        driver.find_element(By.ID, "email").send_keys(email)
        driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
        driver.find_element(By.NAME, "login").click()

        # Wait for login to complete
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
        )
        print("Logged in successfully!")
    except Exception as e:
        print("Failed to log in:", str(e))

# Flexible element click handler function
def safe_click(driver, by, identifier):
    try:
        element = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((by, identifier))
        )
        driver.execute_script("arguments[0].scrollIntoView();", element)
        driver.execute_script("arguments[0].click();", element)
        print(f"Clicked on element: {identifier}")
    except Exception as e:
        print(f"Failed to click on element: {identifier}", str(e))

# Function to create a post
def create_post(driver, message):
    try:
        # Click on "What's on your mind?" element
        safe_click(driver, By.XPATH, "//span[contains(text(), \"What's on your mind. IPhoom\")]") 

        
        
       # Wait for the post input to be available
        post_input = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true']"))
    )

# Once available, click the post input field
        post_input.click()

# Type the message into the input field
        post_input.send_keys(message)

# Set the message content
        print("Post message typed.")

        # Locate and click the "Post" button
        safe_click(driver, By.XPATH, "//div[@aria-label='Post']")
        print("Post submitted!")
    except Exception as e:
        print("Failed to create a post:", str(e))


# Function to schedule a post at specific intervals
def scheduled_post(driver, email, password, post_content, interval_in_seconds):
    # Login to Facebook
    login_facebook(driver, email, password)

    try:
        while True:
            # Create a post
            create_post(driver, post_content)
            
            # Wait for the specified time interval
            print(f"Waiting {interval_in_seconds} seconds before next post...")
            time.sleep(interval_in_seconds)
    except KeyboardInterrupt:
        print("Post scheduling stopped by user.")
    except Exception as e:
        print("An error occurred during scheduling:", str(e))
    finally:
        driver.quit()

# Set up the WebDriver using Service and ChromeDriverManager, and pass Chrome options to block notifications
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service, options=chrome_options)

# Facebook login credentials (consider using environment variables for security)
email = "phakphoom.q@gmail.com"  # Set your environment variable for email
password = "ManManManNoi99&"  # Set your environment variable for password

# Content of the post
post_content = "This is an automated post created using Selenium!"

# Time interval in seconds (for example, 86400 seconds for 24 hours)
interval_in_seconds = 30  # 30 seconds

# Schedule a post every interval (e.g., every 30 seconds)
scheduled_post(driver, email, password, post_content, interval_in_seconds)
