import time
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep
import random
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# Function to post a comment on a Facebook post
def post_comment(driver, comment):
    # Assuming you're already on the post's page
    try:
        # Locate the comment box element by XPath (adjust based on the actual page structure)
        comment_box = driver.find_element("xpath", "//div[@aria-label='Write a comment']")
        comment_box.click()
        sleep(random.uniform(1, 3))  # Random sleep for human-like typing behavior
        
        comment_box.send_keys(comment)
        comment_box.send_keys(Keys.RETURN)
        print("Comment posted!")
    except Exception as e:
        print("Failed to post comment:", str(e))

# Function to search for a topic on Facebook
def search_topic(driver, topic):
    # Go to Facebook search
    try:
        search_box = driver.find_element("xpath", "//input[@aria-label='Search Facebook']")
        search_box.click()
        sleep(1)

        search_box.send_keys(topic)
        search_box.send_keys(Keys.RETURN)
        sleep(3)  # Wait for search results to load
    except Exception as e:
        print("Failed to search topic:", str(e))

# Facebook login
def login_facebook(driver, email, password):
    try:
        driver.get("https://www.facebook.com")
        sleep(3)

        # Input email and password
        email_box = driver.find_element("id", "email")
        password_box = driver.find_element("id", "pass")

        email_box.send_keys(email)
        password_box.send_keys(password)

        # Submit login form
        login_button = driver.find_element("name", "login")
        login_button.click()
        sleep(5)  # Wait for login to complete
    except Exception as e:
        print("Failed to log in:", str(e))

# Set up the WebDriver using Service and ChromeDriverManager
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

# Facebook login credentials (you can log in manually if you prefer)
email = "phakphoom.q@gmail.com"
password = "ManManNoi77&"

# Log into Facebook
login_facebook(driver, email, password)

# Define the topic you want to search
topic = "AI and Machine Learning"

# Start the search process
search_topic(driver, topic)

# Example comments to post
comments = [
    "Great discussion about AI!",
    "I totally agree with the points made here.",
    "Thanks for sharing this information, very helpful.",
]

# Assume you manually navigate to a post where you want to comment
# Loop through and post 5 comments (you can modify this for more comments)
for i in range(5):
    post_comment(driver, random.choice(comments))  # Post a random comment
    sleep(random.uniform(30, 120))  # Random delay between actions

# Close the browser when done
driver.quit()
