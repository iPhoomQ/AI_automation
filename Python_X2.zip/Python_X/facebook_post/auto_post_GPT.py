import time
import openai
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Set your credentials directly in the scriptsk-1g6jm62Mn1AZ2kRuNgkqFCvoU6VoddAzEeuMnXGHC3T3BlbkFJYYJToyu2-1bMRQR8y_j8T397Co0eynaigIcZPtn7oA
OPENAI_API_KEY = "sk-1g6jm62Mn1AZ2kRuNgkqFCvoU6VoddAzEeuMnXGHC3T3BlbkFJYYJToyu2-1bMRQR8y_j8T397Co0eynaigIcZPtn7oA"  # Replace with your OpenAI API key
FB_EMAIL = "phakphoom.q@gmail.com"          # Replace with your Facebook email
FB_PASSWORD = "ManManNoi88&"    # Replace with your Facebook password

# Set up OpenAI API key
openai.api_key = OPENAI_API_KEY

# Set up Chrome options to block notifications
chrome_options = webdriver.ChromeOptions()
prefs = {
    "profile.default_content_setting_values.notifications": 2  # 2 means block notifications
}
chrome_options.add_experimental_option("prefs", prefs)

# Function to find trending topics on Twitter
def find_trending_topic(driver):
    driver.get("https://twitter.com/explore/tabs/trending")
    WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, "//div[@data-testid='trend']"))
    )
    
    # Get the first trending topic
    trending_topic = driver.find_element(By.XPATH, "//div[@data-testid='trend']/span").text
    print(f"Trending Topic: {trending_topic}")
    return trending_topic

# Function to generate a post using OpenAI
def generate_post(topic):
    prompt = f"Create a Facebook post about the trending topic: {topic}"
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    post_content = response['choices'][0]['message']['content']
    return post_content

# Facebook login function
def login_facebook(driver):
    driver.get("https://www.facebook.com")
    WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.ID, "email"))
    )
    driver.find_element(By.ID, "email").send_keys(FB_EMAIL)
    driver.find_element(By.ID, "pass").send_keys(FB_PASSWORD)
    driver.find_element(By.NAME, "login").click()
    WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Create a post']"))
    )
    print("Logged in successfully!")

# Function to create a post on Facebook
def create_post(driver, message):
    post_box = WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), \"What's on your mind\")]"))
    )
    post_box.click()
    
    post_input = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true']"))
    )
    post_input.click()
    post_input.send_keys(message)
    
    post_button = WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//div[@aria-label='Post']"))
    )
    driver.execute_script("arguments[0].click();", post_button)
    print("Post submitted!")

# Main function to run the script
def main():
    # Set up the WebDriver
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)

    # Login to Facebook
    login_facebook(driver)

    # Find trending topic
    trending_topic = find_trending_topic(driver)

    # Generate a post using OpenAI
    post_content = generate_post(trending_topic)

    # Create a post on Facebook
    create_post(driver, post_content)

    # Close the driver
    driver.quit()

if __name__ == "__main__":
    main()
