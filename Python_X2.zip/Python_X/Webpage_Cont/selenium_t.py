import time
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service

# Initialize the Chrome driver using the Service object
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

# Open a website
driver.get("https://www.facebook.com")



email = "phakphoom.q@gmail.com"  # Set your environment variable for email
password = "ManManManNoi99&"  

driver.find_element(By.ID, "email").send_keys(email)
driver.find_element(By.ID, "pass").send_keys(password)

        # Submit login form
driver.find_element(By.NAME, "login").click()

time.sleep(20)

# Find the search box using its name attribute value
search_box = driver.find_element("name", "q")

# Type "Selenium" in the search box
search_box.send_keys("ภาคภูมิ เรืองขจร")

# Press Enter
search_box.send_keys(webdriver.common.keys.Keys.RETURN)

# Wait for 10 seconds to see the result before closing the browser
time.sleep(30)

# Close the browser
driver.quit()
