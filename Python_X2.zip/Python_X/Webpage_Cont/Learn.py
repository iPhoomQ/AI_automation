import selenium
print(selenium.__file__)
